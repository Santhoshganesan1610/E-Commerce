import React from "react";
import SellerDetailsPage from "../Components/SellerDetailsPage";

function SellerDetail() {
  return (
    <div>
      <SellerDetailsPage />
    </div>
  );
}

export default SellerDetail;
