import React from "react";
import TaxDetails from "../Components/TaxDetails";

function TaxDetail() {
  return (
    <div>
      <TaxDetails />
    </div>
  );
}

export default TaxDetail;
