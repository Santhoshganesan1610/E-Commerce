import React from "react";
import PickupAddress from "../Components/PickupAddress";

function AddressPage() {
  return (
    <div>
      <PickupAddress />
    </div>
  );
}

export default AddressPage;
