import React from "react";
import BankDetails from "../Components/BankDetails";

function BankDetail() {
  return (
    <div>
      <BankDetails />
    </div>
  );
}

export default BankDetail;
