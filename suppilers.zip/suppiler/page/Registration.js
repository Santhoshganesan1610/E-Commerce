import React from "react";
import RegistrationPage from "../Components/RegistrationPage";

function Registration() {
  return (
    <div>
      <RegistrationPage />
    </div>
  );
}

export default Registration;
