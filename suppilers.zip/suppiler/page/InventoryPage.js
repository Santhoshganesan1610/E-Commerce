import React from "react";
import InventoryManagement from "../Components/InventoryManagement";

function InventoryPage() {
  return (
    <div>
      <InventoryManagement />
    </div>
  );
}

export default InventoryPage;
