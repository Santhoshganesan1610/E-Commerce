import React, { useState } from 'react';
import PageLayout from '../Layout/PageLayout';
import RightContent from '../Layout/RightContent';
// import './styles.css'; 
import { useNavigate } from "react-router-dom";
// import App from '../santhosh/App';
function SellerDetailsPage() {
    const navigate = useNavigate();
    const [storeName, setStoreName] = useState('');
    const [fullName, setFullName] = useState('');
    const [termsConditions, setTermsConditions] = useState(false);
    const [errors, setErrors] = useState({
      storeName: '',
      fullName: '',
      termsConditions: ''
    });
    const [showModal, setShowModal] = useState(false); // Set initial state of modal to false
  
    const handleSubmit = (event) => {
      event.preventDefault();
      const nameRegex = /^[a-zA-Z\s]+$/; // Regex pattern to allow only letters and spaces
  
      if (validateForm(nameRegex)) {
        navigate('/home');
        // return <navigate to="/App" />;
      }
    };
  
    const validateForm = (nameRegex) => {
      let isValid = true;
      let newErrors = {};
  
      if (storeName.trim() === '') {
        newErrors.storeName = 'Store Name is required.';
        isValid = false;
      } else if (!nameRegex.test(storeName.trim())) {
        newErrors.storeName = 'Store Name should contain only letters and spaces.';
        isValid = false;
      } else {
        newErrors.storeName = '';
      }
  
      if (fullName.trim() === '') {
        newErrors.fullName = 'Full Name is required.';
        isValid = false;
      } else if (!nameRegex.test(fullName.trim())) {
        newErrors.fullName = 'Full Name should contain only letters and spaces.';
        isValid = false;
      } else {
        newErrors.fullName = '';
      }
  
      if (!termsConditions) {
        newErrors.termsConditions = 'Please agree to the Terms and Conditions.';
        isValid = false;
      } else {
        newErrors.termsConditions = '';
      }
  
      setErrors(newErrors);
      return isValid;
    };
  
    const handleStoreNameChange = (event) => {
      const value = event.target.value;
      const nameRegex = /^[a-zA-Z\s]+$/; // Define nameRegex here
      setStoreName(value);
      if (!nameRegex.test(value.trim())) {
        setErrors(prevErrors => ({ ...prevErrors, storeName: 'Store Name should contain only letters and spaces.' }));
      } else {
        setErrors(prevErrors => ({ ...prevErrors, storeName: '' }));
      }
    };
  
    const handleFullNameChange = (event) => {
      const value = event.target.value;
      const nameRegex = /^[a-zA-Z\s]+$/; // Define nameRegex here
      setFullName(value);
      if (!nameRegex.test(value.trim())) {
        setErrors(prevErrors => ({ ...prevErrors, fullName: 'Full Name should contain only letters and spaces.' }));
      } else {
        setErrors(prevErrors => ({ ...prevErrors, fullName: '' }));
      }
    };
  
    const handleTermsConditionsChange = (event) => {
      setTermsConditions(event.target.checked);
      setErrors(prevErrors => ({ ...prevErrors, termsConditions: '' }));
    };
  
    const toggleModal = () => {
      setShowModal(!showModal);
      
      console.log('Modal state:', showModal);
    };
  
    // // Modal content
    // const modalContent = (
    //   <div className="modal-container">
    //     <div className="modal">
    //       <span className="close" onClick={toggleModal}>&times;</span>
    //       <h3>Terms and Conditions</h3>
    //       <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam suscipit purus lectus, nec fringilla purus ultricies eu. Proin gravida dui a ante faucibus, eget accumsan urna dapibus. Integer bibendum lectus vel nulla gravida, nec molestie enim posuere. Vestibulum nec ipsum id sapien tempus hendrerit non at purus. Nam varius consequat odio, ac pharetra purus. Quisque at luctus mauris, non convallis eros. Fusce pharetra, libero non consectetur scelerisque, purus risus malesuada eros, eu convallis nisi nulla vitae quam. Ut lacinia ex ac aliquet gravida. Vivamus a leo eget lacus fermentum fringilla eu a ex. Nulla euismod quam sapien, nec cursus nunc fermentum a.</p>
    //     </div>
    //   </div>
    // );
  
    return (
      <PageLayout
        leftContent={
          <div className="registercontent">
            <h2>Seller Details for Horizon Seller Account</h2>
            <form id="sellerDetailsForm" onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="store_name"><strong>Store Name</strong><span style={{ color: 'red' }}>*</span></label>
                <input
                  type="text"
                  id="store_name"
                  className="form-control"
                  placeholder="Enter Store Name"
                  value={storeName}
                  onChange={handleStoreNameChange}
                />
                <p id="storeNameErrorMsg" className="error-msg">{errors.storeName}</p>
              </div>
              <div className="form-group">
                <label htmlFor="full_name"><strong>Your Full Name</strong><span style={{ color: 'red' }}>*</span></label>
                <input
                  type="text"
                  id="full_name"
                  className="form-control"
                  placeholder="Enter Full Name"
                  value={fullName}
                  onChange={handleFullNameChange}
                />
                <p id="fullNameErrorMsg" className="error-msg">{errors.fullName}</p>
              </div>
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="terms_conditions"
                  checked={termsConditions}
                  onChange={handleTermsConditionsChange}
                />
                <label className="form-check-label" htmlFor="terms_conditions">
                  I agree to the <a href="#" onClick={toggleModal} style={{ color: "blue", cursor: "pointer" }}>Terms and Conditions</a>
                </label>
                <p id="termsErrorMsg" className="error-msg">{errors.termsConditions}</p>
              </div>
              <button type="submit" className="btn btn-success continue-button" style={{ backgroundColor: 'rgb(54, 99, 196)' }}>Submit</button>
            </form>
          </div>
        }
        rightContent={<RightContent title="Importance of Store Name and Terms and Conditions" content="Your store name is crucial for brand recognition and trust-building among customers. Choose a name that reflects your brand identity and is easy to remember. Agreeing to the terms and conditions ensures that you understand and comply with the policies and guidelines set forth by Horizon for successful selling on the platform. It's important to read and understand these terms before proceeding." />}
        specialIconIndex={3}
        showModal={showModal}
        toggleModal={toggleModal}
        // modalContent={modalContent}
      />
    );
  }
  
  export default SellerDetailsPage;
