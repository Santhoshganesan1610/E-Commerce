import React from "react";
import Sidebar from "../component/sidebar";

function MenuBar() {
  return (
    <div>
      <Sidebar/>
    </div>
  );
}

export default MenuBar;