import React from "react";
import Title from "../component/Title";

function Header() {
  return (
    <div>
      <Title />
    </div>
  );
}

export default Header;