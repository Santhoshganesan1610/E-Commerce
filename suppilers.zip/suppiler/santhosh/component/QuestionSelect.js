import React, { useState } from 'react';
import '../../santhosh/title.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const Questionnaire = ({ selectedCategory }) => {
  const [questions, setQuestions] = useState(getQuestionsForCategory(selectedCategory));
  const [selectAll, setSelectAll] = useState(false);
  const [selectedQuestions, setSelectedQuestions] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [newQuestionOpen, setNewQuestionOpen] = useState(false);
  const [newQuestion, setNewQuestion] = useState('');
  const [newAnswer, setNewAnswer] = useState('');



  function getQuestionsForCategory(category) {
    // Define questions for each category here
    const categoryQuestionsMap = {
      Clothing: [
        { id: 4, text: 'Is this sweater made of wool or cotton?', selected: false },
        { id: 5, text: 'What is the recommended washing method for this skirt?', selected: false },
        { id: 6, text: 'Does this pair of jeans have stretch?', selected: false },
        { id: 7, text: 'Are there any special care instructions for this jacket?', selected: false },
        { id: 8, text: 'Does this shirt come in different colors?', selected: false },
        { id: 9, text: 'What is the fabric blend of these trousers?', selected: false },
        { id: 10, text: 'Does this dress have pockets?', selected: false },
      ],
      
      Electronics: [
        { id: 4, text: 'How long is the battery life of this phone?', selected: false },
        { id: 5, text: 'Does this TV support 4K resolution?', selected: false },
        { id: 6, text: 'Is this fan remote-controlled?', selected: false },
        { id: 7, text: 'What is the warranty period for this laptop?', selected: false },
        { id: 8, text: 'Does this camera have image stabilization?', selected: false },
        { id: 9, text: 'Can I connect external speakers to this tablet?', selected: false },
        { id: 10, text: 'What type of ports does this gaming console have?', selected: false },
      ],
      
      Toys: [
        { id: 4, text: 'Is this toy made of eco-friendly materials?', selected: false },
        { id: 5, text: 'Does this playset come with batteries included?', selected: false },
        { id: 6, text: 'Are there any small parts that could be a choking hazard?', selected: false },
        { id: 7, text: 'What is the recommended age range for this board game?', selected: false },
        { id: 8, text: 'Does this puzzle have different difficulty levels?', selected: false },
        { id: 9, text: 'Is this dollhouse easy to assemble?', selected: false },
        { id: 10, text: 'Does this action figure come with any accessories?', selected: false },
      ],
      
    };

    return categoryQuestionsMap[category] || [];
  }

  // Function to handle selection of all questions
  const handleSelectAll = () => {
    const updatedQuestions = questions.map(question => ({
      ...question,
      selected: !selectAll,
    }));
    setQuestions(updatedQuestions);
    setSelectAll(!selectAll);
  };

  // Function to handle selection of individual question
  const handleQuestionSelect = (id) => {
    const updatedQuestions = questions.map(question =>
      question.id === id ? { ...question, selected: !question.selected } : question
    );
    setQuestions(updatedQuestions);
  };

  // Function to handle adding selected questions
  const handleAdd = () => {
    const selectedQuestions = questions.filter(question => question.selected);
    setSelectedQuestions(selectedQuestions);
    setModalOpen(true);
  };

  // Function to close modal
  const handleCloseModal = () => {
    setModalOpen(false);
  };

  // Function to handle adding a new question
  const handleAddQuestion = () => {
    setNewQuestionOpen(true);
  };

  // Function to handle canceling adding a new question
  const handleCancelAddQuestion = () => {
    setNewQuestionOpen(false);
    setNewQuestion('');
    setNewAnswer('');
  };

  // Function to handle submitting a new question
  const handleSubmitQuestion = (event) => {
    event.preventDefault();
    if (newQuestion && newAnswer) {
      const newQuestionObj = {
        id: questions.length + 1,
        text: newQuestion,
        selected: true, // New question is selected by default
      };
      setQuestions([...questions, newQuestionObj]); // Add the new question to the list of questions
      setSelectedQuestions([...selectedQuestions, newQuestionObj]); // Add the new question to the list of selected questions
      setNewQuestionOpen(false);
      setNewQuestion('');
      setNewAnswer('');
    }
  };

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-6" style={{ marginTop: '20px' }}>
          <div className="sellercard">
            <div className="card-body-qa">
              <form className='select'>
                <h3 id='san'>Select Questions</h3>
                {questions.map(question => (
                  <div key={question.id}>
                    <label>
                      <input
                        type="checkbox"
                        checked={question.selected}
                        onChange={() => handleQuestionSelect(question.id)}
                      />
                      {question.text}
                    </label>
                  </div>
                ))}
                <div>
                  <label>
                    <input
                      type="checkbox"
                      checked={selectAll}
                      onChange={handleSelectAll}
                    />
                    Select All
                  </label>
                </div>
                <button className="btn btn-primary" type="button" onClick={handleAdd}>Add</button>
              </form>
            </div>
          </div>
        </div>
        <div className="col-md-6" id='saa'>
          {/* <div className="card"> */}
            <div className="card-body-qa">
              {!newQuestionOpen && (
                <button type="button" onClick={handleAddQuestion} style={{marginLeft:'75%', fontSize:'15px'}}>Add Question</button>
              )}
              {selectedQuestions.length > 0 && (
                <div>
                  <h4>Selected Questions:</h4>
                  <ul>
                    {selectedQuestions.map(question => (
                      <li key={question.id}>{question.text}</li>
                    ))}
                  </ul>
                </div>
              )}
              {newQuestionOpen && (
                <div>
                  <h4>Add New Question:</h4>
                  <form onSubmit={handleSubmitQuestion}>
                    <label id='qa'>
                      Question:
                      <input
                        type="text"
                        value={newQuestion}
                        onChange={(e) => setNewQuestion(e.target.value)}
                      />
                    </label>
                    <br></br>
                    <label id='qa'>
                      Answer:
                      <input
                        type="text"
                        value={newAnswer}
                        onChange={(e) => setNewAnswer(e.target.value)}
                      />
                    </label>
                    <br></br>
                    {/* <button type="submit" id='qa'>Submit</button>
                    <button type="button" onClick={handleCancelAddQuestion}>Cancel</button> */}
                        <button className="btn btn-primary" type="submit" id="qa">Submit</button>
        
                      <button className="btn btn-secondary" type="button" style={{marginTop:'10px'}} onClick={handleCancelAddQuestion}>Cancel</button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    // </div>
  );
};

export default Questionnaire;
