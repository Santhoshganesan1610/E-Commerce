import React from 'react';
import Report from './Report';

function TableDetails() {
  const reportData = [
    { orderId: 'OR123', paymentStatus: 'Paid', deliveryStatus: 'Shipped', orderIssue: 'Delayed delivery', resolution: 'Order rescheduled for faster delivery', date: '2024-03-17' },
    { orderId: 'OR124', paymentStatus: 'Pending', deliveryStatus: 'Processing', orderIssue: 'Payment issue', resolution: 'Customer contacted for payment confirmation', date: '2024-03-18' },
    { orderId: 'OR125', paymentStatus: 'Failed', deliveryStatus: 'Not Shipped', orderIssue: 'Wrong item shipped', resolution: 'Replacement order initiated', date: '2024-03-19' },
    { orderId: 'OR126', paymentStatus: 'Paid', deliveryStatus: 'Delivered', orderIssue: 'Product damaged', resolution: 'Refund processed', date: '2024-03-20' }
  ];

  return (
    <div>
      <Report data={reportData} />
    </div>
  );
}

export default TableDetails;
