import React from 'react';
import '../index.css';
import '../title.css';
import Nav from "react-bootstrap/Nav";

import { Link } from "react-router-dom";
// import Support from '../src/component/Support'
const Sidebar = () => {
    return (
        <div className="container-fluid">
            <div className="row">
                {/* Sidebar */}
                {/* <div className="col-md-3 sidebar"> */}
                    <h4></h4>
                    <ul className="" style={{marginTop:'30px'}} >
                        <li className="sellernav-item" >
                        <Nav.Link as={Link} to="/home ">
                            {/* <a className="nav-link" href="e.html">🏠 Home</a> */}
                            <span>🏠 Home</span>
                            </Nav.Link>
                        </li>
                        <li className="sellernav-item">
                            
                            <Nav.Link as={Link} to="/Inventory">
                            <span>📦 Inventory</span>
                            </Nav.Link>
                        </li>
                        <li className="sellernav-item">
                            <Nav.Link as={Link} to="/ProductRequest ">
                            {/* <a className="nav-link" href="Product.html">ℹ️ Product Q/A</a> */}
                                <span>🛒 Product Request</span>
                            </Nav.Link>
                        </li>
                        <li className="sellernav-item">
                            <Nav.Link as={Link} to="/Product ">
                            {/* <a className="nav-link" href="Product.html">ℹ️ Product Q/A</a> */}
                                <span>ℹ️ Product Q/A</span>
                            </Nav.Link>
                        </li>
                        <li className="sellernav-item">
                             <Nav.Link as={Link} to="/TableDetails ">
                                {/* <a className="nav-link" href="Order.html">📋 Report</a> */}
                                <span>📋 Report</span>
                            </Nav.Link>
                        </li>
                        <li className="sellernav-item">
                             <Nav.Link as={Link} to="/Support ">
                            {/* <a className="nav-link" href="support.html">❤️ Support/Help</a> */}
                            <span >❤️ Support/Help</span>
                            </Nav.Link>
                        </li>
                    </ul>
                    <div className="sidebar-video embed-responsive embed-responsive-16by9">
                        {/* access from one webpage to another web pages, videos, maps,  */}
                        <iframe className="embed-responsive-item" src="https://www.youtube.com/embed/rIJwIrGRYAk" frameborder="0" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        // </div>
    );
}

export default Sidebar;
