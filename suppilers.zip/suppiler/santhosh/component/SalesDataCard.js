// import React from 'react';
// import { Card } from 'react-bootstrap';

// function SalesDataCard({ title, value, icon }) {
//     return (
//         <div className="col">
//             <Card className="order-card" style={{ color: 'white', boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2)', transition: '0.3s', borderRadius: '10px', padding: '5px 5px' }}>
//                 <Card.Body>
//                     <Card.Title as="h2">{title}</Card.Title>
//                     <Card.Text>{value}</Card.Text>
//                     <i className={icon}></i>
//                 </Card.Body>
//             </Card>
//         </div>
//     );
// }

// export default SalesDataCard;
