import React, { useState } from 'react';
import '../title.css';

function Report({ data }) {
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState(null);
  const [filterOption, setFilterOption] = useState('');

  const handleEditClick = (index) => {
    setEditedData(data[index]);
    setEditMode(true);
  };

  const handleSaveClick = () => {
    // You can handle saving the edited data here, for example, by calling an API
    setEditMode(false);
  };

  const handleDeleteClick = (index) => {
    const newData = [...data];
    newData.splice(index, 1);
    // Update the data array by removing the item at the given index
    // setData(newData);
  };

  const handleChange = (e, key) => {
    const { value } = e.target;
    setEditedData((prevState) => ({
      ...prevState,
      [key]: value,
    }));
  };

  const filteredData = () => {
    switch (filterOption) {
      case 'pending':
        return data.filter((item) => item.deliveryStatus === 'Pending');
      case 'delivered':
        return data.filter((item) => item.deliveryStatus === 'Delivered');
      case 'paymentIssue':
        return data.filter((item) => item.orderIssue === 'Payment Issue');
      default:
        return data;
    }
  };

  return (
    <div style={{ marginTop: '80px' }}>
      <h2 className="mt-3" id="product" style={{ marginTop: '50%' }}>
        Report
      </h2>
      <div style={{marginBottom:'10px' }}>
        <select
          value={filterOption}
          onChange={(e) => setFilterOption(e.target.value)}
        >
          <option value="">Filter By</option>
          <option value="pending">Pending</option>
          <option value="delivered">Delivered</option>
          <option value="paymentIssue">Payment Issue</option>
        </select>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th>S.No</th>
            <th>Order ID</th>
            <th>Payment status</th>
            <th>Delivery Status</th>
            <th>Order Issue</th>
            <th>Resolution</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredData().map((item, index) => (
            <tr
              key={index}
              style={{
                backgroundColor:
                  editMode &&
                  editedData &&
                  editedData.orderId === item.orderId
                    ? '#db8d8d'
                    : '',
              }}
            >
              <td>{index + 1}</td>
              <td>
                {editMode && editedData && editedData.orderId === item.orderId ? (
                  <input
                    type="text"
                    value={editedData.orderId}
                    onChange={(e) => handleChange(e, 'orderId')}
                  />
                ) : (
                  item.orderId
                )}
              </td>
              <td>
                {editMode && editedData && editedData.orderId === item.orderId ? (
                  <input
                    type="text"
                    value={editedData.paymentStatus}
                    onChange={(e) => handleChange(e, 'paymentStatus')}
                  />
                ) : (
                  item.paymentStatus
                )}
              </td>
              <td>
                {editMode && editedData && editedData.orderId === item.orderId ? (
                  <input
                    type="text"
                    value={editedData.deliveryStatus}
                    onChange={(e) => handleChange(e, 'deliveryStatus')}
                  />
                ) : (
                  item.deliveryStatus
                )}
              </td>
              <td>
                {editMode && editedData && editedData.orderId === item.orderId ? (
                  <input
                    type="text"
                    value={editedData.orderIssue}
                    onChange={(e) => handleChange(e, 'orderIssue')}
                  />
                ) : (
                  item.orderIssue
                )}
              </td>
              <td>
                {editMode && editedData && editedData.orderId === item.orderId ? (
                  <input
                    type="text"
                    value={editedData.resolution}
                    onChange={(e) => handleChange(e, 'resolution')}
                  />
                ) : (
                  item.resolution
                )}
              </td>
              <td>
                {editMode && editedData && editedData.orderId === item.orderId ? (
                  <input
                    type="text"
                    value={editedData.date}
                    onChange={(e) => handleChange(e, 'date')}
                  />
                ) : (
                  item.date
                )}
              </td>
              <td>
                {editMode && editedData && editedData.orderId === item.orderId ? (
                  <span className="save-icon" onClick={handleSaveClick}>
                    &#128190;
                  </span>
                ) : (
                  <span
                    className="edit-icon"
                    onClick={() => handleEditClick(index)}
                  >
                    &#9998;
                  </span>
                )}
                <span
                  className="delete-icon"
                  onClick={() => handleDeleteClick(index)}
                >
                  &#128465;
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Report;
