// Howitsworks.js
import React from 'react';
import BusinessComponent from '../component/BusinessComponent';
import BusinessGrowth from '../component/BusinessGrowth';
import MainComponent from '../component/MainComponent';
import BenefitWorks from '../component/BenefitWorks';

import '../App.css';
import SupportComponent from '../component/SupportComponent';

function Howitsworks() {
  return (
    <div>
  <BusinessComponent />
<BusinessGrowth />
<BenefitWorks />

<MainComponent />
<SupportComponent />
{/* <Footer /> */}


    </div>
  )
}

export default Howitsworks;
