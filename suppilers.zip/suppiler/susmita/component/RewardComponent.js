import React from 'react';
import '../App.css';
function RewardComponent() {
  return (
    <div className="col-md-4">
      <div className="ui-p-container">
        <h1 id="ui-para1"><b>Exclusive Supplier+ Rewards</b></h1>
        <h3><b> for the first 30 days</b></h3>
      </div>
    </div>
  );
}

export default RewardComponent;