import React from 'react';
import '../App.css';

function Growbusiness() {
  return (
    <div style={{ textAlign: 'center' }}>
      <h2 className="ui-register-header mb-5" style={{ fontSize: '24px', color: 'black' }}>How to Grow Your Online Selling Business on Horizon?</h2>
      <p className="ui-register-paragraphs mb-5" style={{ fontSize: '18px', color: 'black' }}>After you get your first order, it is time to start growing your online selling business! Some factors that help you building your online business are:</p>
      {/* Add additional content or components here if needed */}
    </div>
  );
}

export default Growbusiness;
