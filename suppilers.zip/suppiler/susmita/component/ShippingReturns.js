// ShippingReturns.js
import React from 'react';

import ResourceComponent from './ResourceComponent';
import DifferentComponent from './DifferentComponent';

function ShippingReturns() {
  return (
    <div>
<DifferentComponent />
      <ResourceComponent />
    </div>
  )
}

export default ShippingReturns;

